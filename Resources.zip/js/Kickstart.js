﻿function loadProjects(mid) {

    var sf = $.ServicesFramework(mid);

    $.ajax({
        type: "GET",
        url: sf.getServiceRoot('Connect/Kickstart') + 'Kickstart/GetProjectList',
        beforeSend: sf.setModuleHeaders,
        success: function (data) {
            if (data.length > 0) {
                $(".kickstart-projectlist").hide().html(data).slideDown("slow");
            }
            if (typeof (callback) != "undefined") {
                callback(data);
            }
        },
        error: function (xhr, status, error) {
            alert(error);
        }
    });

}

function loadProject(mid,projectId) {

    var sf = $.ServicesFramework(mid);

    $.ajax({
        type: "GET",
        url: sf.getServiceRoot('Connect/Kickstart') + 'Kickstart/GetProject?ProjectId=' + projectId,
        beforeSend: sf.setModuleHeaders,
        success: function (data) {
            if (data.length > 0) {
                $(".kickstart-projectdetails").hide().html(data).slideDown("slow");
            }
            if (typeof (callback) != "undefined") {
                callback(data);
            }
        },
        error: function (xhr, status, error) {
            alert(error);
        }
    });

}

function ApproveProject(mid, projectId) {

    var sf = $.ServicesFramework(mid);

    $.ajax({
        type: "GET",
        url: sf.getServiceRoot('Connect/Kickstart') + 'Kickstart/ApproveProject?ProjectId=' + projectId,
        beforeSend: sf.setModuleHeaders,
        success: function (data) {
            if (data.length > 0) {
                $(".kickstart-projectdetails").hide().html(data).slideDown("slow");
            }
            if (typeof (callback) != "undefined") {
                callback(data);
            }
        },
        error: function (xhr, status, error) {
            alert(error);
        }
    });

}

function UnApproveProject(mid, projectId) {

    var sf = $.ServicesFramework(mid);

    $.ajax({
        type: "GET",
        url: sf.getServiceRoot('Connect/Kickstart') + 'Kickstart/UnApproveProject?ProjectId=' + projectId,
        beforeSend: sf.setModuleHeaders,
        success: function (data) {
            if (data.length > 0) {
                $(".kickstart-projectdetails").hide().html(data).slideDown("slow");
            }
            if (typeof (callback) != "undefined") {
                callback(data);
            }
        },
        error: function (xhr, status, error) {
            alert(error);
        }
    });

}