﻿Imports System
Imports System.Net
Imports System.Net.Http
Imports System.Web.Http
Imports DotNetNuke.Web.Api
Imports DotNetNuke.Services.Localization
Imports System.IO
Imports Connect.Modules.Kickstart.Entities
Imports Connect.Modules.Kickstart.Templates

Namespace Connect.Modules.Kickstart.Services

    Public Class KickstartController
        Inherits DnnApiController

        <AllowAnonymous> <HttpGet> _
        Public Function GetProjectList() As HttpResponseMessage

            Dim objKickstartSettings As KickstartSettings = New KickstartSettings(ActiveModule.ModuleSettings())

            Dim projects As New List(Of ProjectInfo)
            projects = ProjectController.ListByModules(ActiveModule.ModuleID)

            Dim strHtml As String = ""

            ProjectTemplateController.ProcessCommonTemplate(strHtml, TemplateHelper.Template_ProjectHeader, projects, objKickstartSettings)
            For Each objProject As ProjectInfo In projects
                ProjectTemplateController.ProcessItemTemplate(strHtml, TemplateHelper.Template_ProjectItem, objProject, objKickstartSettings)
            Next
            ProjectTemplateController.ProcessCommonTemplate(strHtml, TemplateHelper.Template_ProjectFooter, projects, objKickstartSettings)

            Return Request.CreateResponse(HttpStatusCode.OK, strHtml)

        End Function

        <AllowAnonymous> <HttpGet> _
        Public Function GetProject(<FromUri> ProjectId As Integer) As HttpResponseMessage

            Dim objKickstartSettings As KickstartSettings = New KickstartSettings(ActiveModule.ModuleSettings())

            Dim objProject As ProjectInfo = ProjectController.Get(ProjectId)
            If Not objProject Is Nothing Then

                Dim strHtml As String = ""
                ProjectTemplateController.ProcessItemTemplate(strHtml, TemplateHelper.Template_ProjectDetails, objProject, objKickstartSettings)
                Return Request.CreateResponse(HttpStatusCode.OK, strHtml)

            End If

            Return Request.CreateResponse(HttpStatusCode.OK, Utilities.GetSharedResource("ProjectNotFound"))

        End Function

        <AllowAnonymous> <HttpGet> _
        Public Function ApproveProject(<FromUri> ProjectId As Integer) As HttpResponseMessage

            Dim objKickstartSettings As KickstartSettings = New KickstartSettings(ActiveModule.ModuleSettings())

            Dim objProject As ProjectInfo = ProjectController.Get(ProjectId)
            objProject.IsVisible = True
            ProjectController.Update(objProject)

            If Not objProject Is Nothing Then

                Dim strHtml As String = ""
                ProjectTemplateController.ProcessItemTemplate(strHtml, TemplateHelper.Template_ProjectDetails, objProject, objKickstartSettings)
                Return Request.CreateResponse(HttpStatusCode.OK, strHtml)

            End If

            Return Request.CreateResponse(HttpStatusCode.OK, Utilities.GetSharedResource("ProjectNotFound"))

        End Function

        <AllowAnonymous> <HttpGet> _
        Public Function UnApproveProject(<FromUri> ProjectId As Integer) As HttpResponseMessage

            Dim objKickstartSettings As KickstartSettings = New KickstartSettings(ActiveModule.ModuleSettings())

            Dim objProject As ProjectInfo = ProjectController.Get(ProjectId)
            objProject.IsVisible = False
            ProjectController.Update(objProject)

            If Not objProject Is Nothing Then

                Dim strHtml As String = ""
                ProjectTemplateController.ProcessItemTemplate(strHtml, TemplateHelper.Template_ProjectDetails, objProject, objKickstartSettings)
                Return Request.CreateResponse(HttpStatusCode.OK, strHtml)

            End If

            Return Request.CreateResponse(HttpStatusCode.OK, Utilities.GetSharedResource("ProjectNotFound"))

        End Function

    End Class

End Namespace

