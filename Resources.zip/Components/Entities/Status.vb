﻿Namespace Connect.Modules.Kickstart

    Public Class Enums

        Public Enum ProjectStatus
            Suggested = 1
            Active = 2
        End Enum

    End Class


End Namespace