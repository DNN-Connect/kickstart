﻿Imports DotNetNuke.Entities.Modules


Namespace Connect.Modules.Kickstart
    Public Class SettingsBase
        Inherits ModuleSettingsBase



    End Class
End Namespace

