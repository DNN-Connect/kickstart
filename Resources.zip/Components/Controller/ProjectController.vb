Imports DotNetNuke.Data
Imports DotNetNuke.Framework
Imports System.Collections.Generic
imports System.ComponentModel

Namespace Connect.Modules.Kickstart.Entities

	<DataObject(True)> _
	Public Class ProjectController
	
#Region "Private Methods"
        Public Shared Function GetNull(ByVal Field As Object) As Object
            Return DotNetNuke.Common.Utilities.Null.GetNull(Field, DBNull.Value)
        End Function
#End Region

#Region "Public Methods"

        Public Shared Function [Get](ByVal projectId As Integer) As ProjectInfo

            Return CType(CBO.FillObject(DotNetNuke.Data.DataProvider.Instance().ExecuteReader("Connect_Kickstart_Project_Get", projectId), GetType(ProjectInfo)), ProjectInfo)

        End Function

        <DataObjectMethod(DataObjectMethodType.Select, True)> _
        Public Shared Function [List]() As List(Of ProjectInfo)

            Return CBO.FillCollection(Of ProjectInfo)(CType(DotNetNuke.Data.DataProvider.Instance().ExecuteReader("Connect_Kickstart_Project_List"), IDataReader))

        End Function

        <DataObjectMethod(DataObjectMethodType.Select, True)> _
        Public Shared Function [ListByModules](ByVal ModuleId As Integer) As List(Of ProjectInfo)

            Return CBO.FillCollection(Of ProjectInfo)(CType(DotNetNuke.Data.DataProvider.Instance().ExecuteReader("Connect_Kickstart_Project_ListByModules", ModuleId), IDataReader))

        End Function

        <DataObjectMethod(DataObjectMethodType.Insert, True)> _
        Public Shared Function Add(ByVal objProjectInfo As ProjectInfo) As Integer

            Return DotNetNuke.Data.DataProvider.Instance().ExecuteScalar(Of Integer)("Connect_Kickstart_Project_Add", objProjectInfo.ModuleId, objProjectInfo.ContentItemId, objProjectInfo.Status, objProjectInfo.Subject, objProjectInfo.Summary, objProjectInfo.Content, GetNull(objProjectInfo.ProjectUrl), GetNull(objProjectInfo.ProjectPlatform), GetNull(objProjectInfo.PlatformRssUrl), GetNull(objProjectInfo.DateScheduled), GetNull(objProjectInfo.DateDelivered), objProjectInfo.DateCreated, GetNull(objProjectInfo.DateLocked), GetNull(objProjectInfo.DateDeleted), objProjectInfo.CreatedBy, GetNull(objProjectInfo.LockedBy), GetNull(objProjectInfo.DeletedBy), GetNull(objProjectInfo.LeadBy), objProjectInfo.IsVisible, objProjectInfo.IsLocked, objProjectInfo.IsDeleted, objProjectInfo.IsDelivered, objProjectInfo.Views, objProjectInfo.Comments, objProjectInfo.Votes, objProjectInfo.TeamMembers)

        End Function
	
        <DataObjectMethod(DataObjectMethodType.Update, True)> _
        Public Shared Sub Update(ByVal objProjectInfo As ProjectInfo)

            DotNetNuke.Data.DataProvider.Instance().ExecuteNonQuery("Connect_Kickstart_Project_Update", objProjectInfo.ProjectId, objProjectInfo.ModuleId, objProjectInfo.ContentItemId, objProjectInfo.Status, objProjectInfo.Subject, objProjectInfo.Summary, objProjectInfo.Content, GetNull(objProjectInfo.ProjectUrl), GetNull(objProjectInfo.ProjectPlatform), GetNull(objProjectInfo.PlatformRssUrl), GetNull(objProjectInfo.DateScheduled), GetNull(objProjectInfo.DateDelivered), objProjectInfo.DateCreated, GetNull(objProjectInfo.DateLocked), GetNull(objProjectInfo.DateDeleted), objProjectInfo.CreatedBy, GetNull(objProjectInfo.LockedBy), GetNull(objProjectInfo.DeletedBy), GetNull(objProjectInfo.LeadBy), objProjectInfo.IsVisible, objProjectInfo.IsLocked, objProjectInfo.IsDeleted, objProjectInfo.IsDelivered, objProjectInfo.Views, objProjectInfo.Comments, objProjectInfo.Votes, objProjectInfo.TeamMembers)
        End Sub
		
        <DataObjectMethod(DataObjectMethodType.Delete, True)> _
        Public Shared Sub Delete(ByVal ProjectId As Integer)

            DotNetNuke.Data.DataProvider.Instance().ExecuteNonQuery("Connect_Kickstart_Project_Delete", ProjectId)

        End Sub
    
#End Region

	End Class



End Namespace