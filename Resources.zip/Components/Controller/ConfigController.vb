﻿Imports Microsoft.VisualBasic
Imports DotNetNuke
Imports DotNetNuke.Common.Utilities
Imports Connect.Modules.Kickstart.Entities


Namespace Connect.Modules.Kickstart

    Public Class ConfigController

        Public Shared Sub UpdateOwnership(ProjectId As Integer, OwnerId As Integer)

            Dim dicConfig As New Dictionary(Of String, String)
            Dim dr As IDataReader = CType(DotNetNuke.Data.DataProvider.Instance().ExecuteReader("Connect_Kickstart_GetConfig", ProjectId), IDataReader)
            While dr.Read
                dicConfig.Add(Convert.ToString(dr("Setting")), Convert.ToString(dr("Value")))
            End While
            dr.Close()
            dr.Dispose()

            If Not dicConfig.ContainsKey("ProjectOwner") Then
                DotNetNuke.Data.DataProvider.Instance().ExecuteNonQuery("Connect_Kickstart_AddConfig", ProjectId, "ProjectOwner", OwnerId.ToString)
            Else
                DotNetNuke.Data.DataProvider.Instance().ExecuteNonQuery("Connect_Kickstart_UpdateConfig", ProjectId, "ProjectOwner", OwnerId.ToString)
            End If

        End Sub

        Public Shared Sub UpdateConfig(ProjectId As Integer, Developers As Integer, Designers As Integer, Testers As Integer, Managers As Integer, Translators As Integer, Funding As Decimal, Currency As String)

            Dim dicConfig As New Dictionary(Of String, String)
            Dim dr As IDataReader = CType(DotNetNuke.Data.DataProvider.Instance().ExecuteReader("Connect_Kickstart_GetConfig", ProjectId), IDataReader)
            While dr.Read
                dicConfig.Add(Convert.ToString(dr("Setting")), Convert.ToString(dr("Value")))
            End While
            dr.Close()
            dr.Dispose()

            If Not dicConfig.ContainsKey("DesignersNeeded") Then
                DotNetNuke.Data.DataProvider.Instance().ExecuteNonQuery("Connect_Kickstart_AddConfig", ProjectId, "DesignersNeeded", Designers.ToString)
            Else
                DotNetNuke.Data.DataProvider.Instance().ExecuteNonQuery("Connect_Kickstart_UpdateConfig", ProjectId, "DesignersNeeded", Designers.ToString)
            End If

            If Not dicConfig.ContainsKey("DevelopersNeeded") Then
                DotNetNuke.Data.DataProvider.Instance().ExecuteNonQuery("Connect_Kickstart_AddConfig", ProjectId, "DevelopersNeeded", Developers.ToString)
            Else
                DotNetNuke.Data.DataProvider.Instance().ExecuteNonQuery("Connect_Kickstart_UpdateConfig", ProjectId, "DevelopersNeeded", Developers.ToString)
            End If

            If Not dicConfig.ContainsKey("FundingNeeded") Then
                DotNetNuke.Data.DataProvider.Instance().ExecuteNonQuery("Connect_Kickstart_AddConfig", ProjectId, "FundingNeeded", Funding.ToString)
            Else
                DotNetNuke.Data.DataProvider.Instance().ExecuteNonQuery("Connect_Kickstart_UpdateConfig", ProjectId, "FundingNeeded", Funding.ToString)
            End If

            If Not dicConfig.ContainsKey("ManagersNeeded") Then
                DotNetNuke.Data.DataProvider.Instance().ExecuteNonQuery("Connect_Kickstart_AddConfig", ProjectId, "ManagersNeeded", Managers.ToString)
            Else
                DotNetNuke.Data.DataProvider.Instance().ExecuteNonQuery("Connect_Kickstart_UpdateConfig", ProjectId, "ManagersNeeded", Managers.ToString)
            End If

            If Not dicConfig.ContainsKey("TestersNeeded") Then
                DotNetNuke.Data.DataProvider.Instance().ExecuteNonQuery("Connect_Kickstart_AddConfig", ProjectId, "TestersNeeded", Testers.ToString)
            Else
                DotNetNuke.Data.DataProvider.Instance().ExecuteNonQuery("Connect_Kickstart_UpdateConfig", ProjectId, "TestersNeeded", Testers.ToString)
            End If

            If Not dicConfig.ContainsKey("TranslatorsNeeded") Then
                DotNetNuke.Data.DataProvider.Instance().ExecuteNonQuery("Connect_Kickstart_AddConfig", ProjectId, "TranslatorsNeeded", Translators.ToString)
            Else
                DotNetNuke.Data.DataProvider.Instance().ExecuteNonQuery("Connect_Kickstart_UpdateConfig", ProjectId, "TranslatorsNeeded", Translators.ToString)
            End If

            If Not dicConfig.ContainsKey("FundingCurrency") Then
                DotNetNuke.Data.DataProvider.Instance().ExecuteNonQuery("Connect_Kickstart_AddConfig", ProjectId, "FundingCurrency", Currency.ToString)
            Else
                DotNetNuke.Data.DataProvider.Instance().ExecuteNonQuery("Connect_Kickstart_UpdateConfig", ProjectId, "FundingCurrency", Currency.ToString)
            End If

        End Sub

        Public Shared Function GetConfig(ProjectId As Integer) As ProjectConfigInfo

            Dim dicConfig As New Dictionary(Of String, String)
            Dim dr As IDataReader = CType(DotNetNuke.Data.DataProvider.Instance().ExecuteReader("Connect_Kickstart_GetConfig", ProjectId), IDataReader)
            While dr.Read
                dicConfig.Add(Convert.ToString(dr("Setting")), Convert.ToString(dr("Value")))
            End While
            dr.Close()
            dr.Dispose()


            Dim config As New ProjectConfigInfo

            If dicConfig.ContainsKey("ProjectOwner") Then
                config.ProjectOwner = Convert.ToInt32(dicConfig("ProjectOwner"))
            End If

            If dicConfig.ContainsKey("DesignersNeeded") Then
                If dicConfig("DesignersNeeded") <> "0" Then
                    config.DesignersNeeded = Convert.ToInt32(dicConfig("DesignersNeeded"))
                    config.InitializedOnly = False
                End If
            End If


            If dicConfig.ContainsKey("DevelopersNeeded") Then
                If dicConfig("DevelopersNeeded") <> "0" Then
                    config.DevelopersNeeded = Convert.ToInt32(dicConfig("DevelopersNeeded"))
                    config.InitializedOnly = False
                End If
            End If


            If dicConfig.ContainsKey("FundingNeeded") Then
                If dicConfig("FundingNeeded") <> "0" Then
                    config.FundingNeeded = Convert.ToDecimal(dicConfig("FundingNeeded"))
                    config.InitializedOnly = False
                End If
            End If


            If dicConfig.ContainsKey("ManagersNeeded") Then
                If dicConfig("ManagersNeeded") <> "0" Then
                    config.ManagersNeeded = Convert.ToInt32(dicConfig("ManagersNeeded"))
                    config.InitializedOnly = False
                End If
            End If


            If dicConfig.ContainsKey("TestersNeeded") Then
                If dicConfig("TestersNeeded") <> "0" Then
                    config.TestersNeeded = Convert.ToInt32(dicConfig("TestersNeeded"))
                    config.InitializedOnly = False
                End If
            End If


            If dicConfig.ContainsKey("TranslatorsNeeded") Then
                If dicConfig("TranslatorsNeeded") <> "0" Then
                    config.TranslatorsNeeded = Convert.ToInt32(dicConfig("TranslatorsNeeded"))
                    config.InitializedOnly = False
                End If
            End If

            If dicConfig.ContainsKey("FundingCurrency") Then
                If dicConfig("FundingCurrency") <> "0" Then
                    config.FundingCurrency = Convert.ToString(dicConfig("FundingCurrency"))
                    config.InitializedOnly = False
                End If
            End If


            Return config

        End Function

    End Class

End Namespace


