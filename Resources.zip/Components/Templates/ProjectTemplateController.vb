﻿Imports Connect.Modules.Kickstart.Entities
Imports DotNetNuke.Entities.Users
Imports DotNetNuke.Entities.Portals

Namespace Connect.Modules.Kickstart.Templates

    Public Class ProjectTemplateController

        Public Shared Sub ProcessCommonTemplate(ByRef strHtml As String, ByVal strTemplateFile As String, ByVal objProjectList As List(Of ProjectInfo), Settings As KickstartSettings)

            Dim strTemplate As String = TemplateHelper.ReadTemplate(Settings.ThemePath & strTemplateFile)

            Dim Portalsettings As PortalSettings = PortalController.GetCurrentPortalSettings

            Dim literal As New Literal
            Dim delimStr As String = "[]"
            Dim delimiter As Char() = delimStr.ToCharArray()

            Dim templateArray As String()
            templateArray = strTemplate.Split(delimiter)

            For iPtr As Integer = 0 To templateArray.Length - 1 Step 2

                strHtml += templateArray(iPtr).ToString()

                If iPtr < templateArray.Length - 1 Then

                    Select Case templateArray(iPtr + 1).ToLower

                        Case "cansubmit"

                            If HttpContext.Current.Request.IsAuthenticated = False Then
                                While (iPtr < templateArray.Length - 1)
                                    If (templateArray(iPtr + 1).ToLower = "/cansubmit") Then
                                        Exit While
                                    End If
                                    iPtr = iPtr + 1
                                End While
                            End If

                        Case "createideaurl"

                            strHtml += NavigateURL(Portalsettings.ActiveTab.TabID, "", "Action=Create")

                        Case Else

                            If (templateArray(iPtr + 1).ToUpper().StartsWith("RESX:")) Then

                                Dim key As String = templateArray(iPtr + 1).Substring(5, templateArray(iPtr + 1).Length - 5)
                                Dim strText As String = Utilities.GetSharedResource(key)
                                strHtml += strText

                            End If

                    End Select
                End If
            Next
        End Sub

        Public Shared Sub ProcessItemTemplate(ByRef strHtml As String, ByVal strTemplateFile As String, ByVal objProject As ProjectInfo, ByVal Settings As KickstartSettings)

            Dim strTemplate As String = TemplateHelper.ReadTemplate(Settings.ThemePath & strTemplateFile)
            Dim usrCreatedBy As UserInfo = Nothing
            Dim usrLockedBy As UserInfo = Nothing
            Dim usrDeletedBy As UserInfo = Nothing
            Dim usrLead As UserInfo = Nothing
            Dim Portalsettings As PortalSettings = PortalController.GetCurrentPortalSettings

            Dim literal As New Literal
            Dim delimStr As String = "[]"
            Dim delimiter As Char() = delimStr.ToCharArray()

            Dim templateArray As String()
            templateArray = strTemplate.Split(delimiter)

            For iPtr As Integer = 0 To templateArray.Length - 1 Step 2

                strHtml += templateArray(iPtr).ToString()

                If iPtr < templateArray.Length - 1 Then

                    Select Case templateArray(iPtr + 1).ToLower

                        Case "moduleid"

                            strHtml += objProject.ModuleId.ToString

                        Case "contentitemid"

                            strHtml += objProject.ContentItemId

                        Case "statusid"

                            strHtml += objProject.Status.ToString

                        Case "status"

                            strHtml += Utilities.GetSharedResource(CType(objProject.Status, Enums.ProjectStatus).ToString)

                        Case "subject"

                            strHtml += objProject.Subject

                        Case "summary"

                            strHtml += HttpUtility.HtmlDecode(objProject.Summary)

                        Case "content"

                            strHtml += HttpUtility.HtmlDecode(objProject.Content)

                        Case "projecturl"

                            strHtml += objProject.ProjectUrl

                        Case "projectplatform"

                            strHtml += objProject.ProjectPlatform

                        Case "platformrssurl"

                            strHtml += objProject.PlatformRssUrl

                        Case "datescheduled"

                            strHtml += objProject.DateScheduled.ToShortDateString

                        Case "datelocked"

                            strHtml += objProject.DateLocked.ToShortDateString

                        Case "datedelivered"

                            strHtml += objProject.DateDelivered.ToShortDateString

                        Case "datedeleted"

                            strHtml += objProject.DateDeleted.ToShortDateString

                        Case "datecreated"

                            strHtml += objProject.DateCreated.ToShortDateString

                        Case "datescheduled"

                            strHtml += objProject.DateScheduled.ToShortDateString

                        Case "createdbyuserid"

                            If usrCreatedBy Is Nothing Then
                                usrCreatedBy = UserController.GetUserById(Portalsettings.PortalId, objProject.CreatedBy)
                            End If

                            strHtml += usrCreatedBy.UserID.ToString

                        Case "createdbydisplayname"

                            If usrCreatedBy Is Nothing Then
                                usrCreatedBy = UserController.GetUserById(Portalsettings.PortalId, objProject.CreatedBy)
                            End If

                            strHtml += usrCreatedBy.DisplayName

                        Case "createdbyprofileurl"

                            If usrCreatedBy Is Nothing Then
                                usrCreatedBy = UserController.GetUserById(Portalsettings.PortalId, objProject.CreatedBy)
                            End If

                            strHtml += NavigateURL(Portalsettings.UserTabId, "", "UserId=" & usrCreatedBy.UserID)

                        Case "createdbypictureurl"

                            If usrCreatedBy Is Nothing Then
                                usrCreatedBy = UserController.GetUserById(Portalsettings.PortalId, objProject.CreatedBy)
                            End If

                            strHtml += String.Format("~/profilepic.ashx?userId={0}&h={1}&w={2}", usrCreatedBy.UserID.ToString, "32", "32")

                        Case "lockedbyuserid"

                            If usrLockedBy Is Nothing Then
                                usrLockedBy = UserController.GetUserById(Portalsettings.PortalId, objProject.LockedBy)
                            End If

                            strHtml += usrLockedBy.UserID.ToString

                        Case "lockedbydisplayname"

                            If usrLockedBy Is Nothing Then
                                usrLockedBy = UserController.GetUserById(Portalsettings.PortalId, objProject.LockedBy)
                            End If

                            strHtml += usrLockedBy.DisplayName

                        Case "lockedbyprofileurl"

                            If usrLockedBy Is Nothing Then
                                usrLockedBy = UserController.GetUserById(Portalsettings.PortalId, objProject.LockedBy)
                            End If

                            strHtml += NavigateURL(Portalsettings.UserTabId, "", "UserId=" & usrLockedBy.UserID)

                        Case "lockedbypictureurl"

                            If usrLockedBy Is Nothing Then
                                usrLockedBy = UserController.GetUserById(Portalsettings.PortalId, objProject.LockedBy)
                            End If

                            strHtml += String.Format("~/profilepic.ashx?userId={0}&h={1}&w={2}", usrLockedBy.UserID.ToString, "32", "32")

                        Case "deletedbyuserid"

                            If usrDeletedBy Is Nothing Then
                                usrDeletedBy = UserController.GetUserById(Portalsettings.PortalId, objProject.DeletedBy)
                            End If

                            strHtml += usrDeletedBy.UserID.ToString

                        Case "deletedbydisplayname"

                            If usrDeletedBy Is Nothing Then
                                usrDeletedBy = UserController.GetUserById(Portalsettings.PortalId, objProject.DeletedBy)
                            End If

                            strHtml += usrDeletedBy.DisplayName

                        Case "deletedbyprofileurl"

                            If usrDeletedBy Is Nothing Then
                                usrDeletedBy = UserController.GetUserById(Portalsettings.PortalId, objProject.DeletedBy)
                            End If

                            strHtml += NavigateURL(Portalsettings.UserTabId, "", "UserId=" & usrDeletedBy.UserID)

                        Case "deletedbypictureurl"

                            If usrDeletedBy Is Nothing Then
                                usrDeletedBy = UserController.GetUserById(Portalsettings.PortalId, objProject.DeletedBy)
                            End If

                            strHtml += String.Format("~/profilepic.ashx?userId={0}&h={1}&w={2}", usrDeletedBy.UserID.ToString, "32", "32")

                        Case "leadbyuserid"

                            If usrLead Is Nothing Then
                                usrLead = UserController.GetUserById(Portalsettings.PortalId, objProject.LeadBy)
                            End If

                            strHtml += usrLead.UserID.ToString

                        Case "leadbydisplayname"

                            If usrLead Is Nothing Then
                                usrLead = UserController.GetUserById(Portalsettings.PortalId, objProject.LeadBy)
                            End If

                            strHtml += usrLead.DisplayName

                        Case "leadbyprofileurl"

                            If usrLead Is Nothing Then
                                usrLead = UserController.GetUserById(Portalsettings.PortalId, objProject.LeadBy)
                            End If

                            strHtml += NavigateURL(Portalsettings.UserTabId, "", "UserId=" & usrLead.UserID)

                        Case "leadbypictureurl"

                            If usrLead Is Nothing Then
                                usrLead = UserController.GetUserById(Portalsettings.PortalId, objProject.LeadBy)
                            End If

                            strHtml += String.Format("~/profilepic.ashx?userId={0}&h={1}&w={2}", usrLead.UserID.ToString, "32", "32")

                        Case "isvisible"

                            Dim strKey As String = ""
                            If objProject.IsVisible Then
                                strKey = "Published"
                            Else
                                strKey = "UnPublished"
                            End If

                            strHtml += Utilities.GetSharedResource(strKey)

                        Case "islocked"

                            Dim strKey As String = ""
                            If objProject.IsLocked Then
                                strKey = "Locked"
                            Else
                                strKey = "UnLocked"
                            End If

                            strHtml += Utilities.GetSharedResource(strKey)

                        Case "isdeleted"

                            Dim strKey As String = ""
                            If objProject.IsDeleted Then
                                strKey = "Deleted"
                            Else
                                strKey = "NotDeleted"
                            End If

                            strHtml += Utilities.GetSharedResource(strKey)

                        Case "isdelivered"

                            Dim strKey As String = ""
                            If objProject.IsDeleted Then
                                strKey = "Delivered"
                            Else
                                strKey = "NotDelivered"
                            End If

                            strHtml += Utilities.GetSharedResource(strKey)

                        Case "views"

                            strHtml += objProject.Views.ToString

                        Case "comments"

                            strHtml += objProject.Comments.ToString

                        Case "votes"

                            strHtml += objProject.Votes.ToString

                        Case "teammembers"

                            strHtml += objProject.TeamMembers.ToString

                        Case "haslead"

                            If objProject.LeadBy <> Null.NullInteger Then
                                While (iPtr < templateArray.Length - 1)
                                    If (templateArray(iPtr + 1).ToLower = "/haslead") Then
                                        Exit While
                                    End If
                                    iPtr = iPtr + 1
                                End While
                            End If

                        Case "iseditor"

                            If Not Utilities.CanEdit(objProject) Then
                                While (iPtr < templateArray.Length - 1)
                                    If (templateArray(iPtr + 1).ToLower = "/iseditor") Then
                                        Exit While
                                    End If
                                    iPtr = iPtr + 1
                                End While
                            End If

                        Case "hasnolead"

                            If objProject.LeadBy = Null.NullInteger Then
                                While (iPtr < templateArray.Length - 1)
                                    If (templateArray(iPtr + 1).ToLower = "/hasnolead") Then
                                        Exit While
                                    End If
                                    iPtr = iPtr + 1
                                End While
                            End If

                        Case "detailurl"

                            strHtml += NavigateURL(Settings.ProjectDetailsTabId, "", "ProjectId=" & objProject.ProjectId.ToString)

                        Case "comments"

                            Dim lstComments As List(Of CommentInfo) = CommentController.ListByProject(objProject.ProjectId)
                            CommentsTemplateController.ProcessCommonTemplate(strHtml, TemplateHelper.Template_CommentHeader, lstComments, Settings)
                            For Each objComment As CommentInfo In lstComments
                                CommentsTemplateController.ProcessItemTemplate(strHtml, TemplateHelper.Template_CommentItem, objComment, Settings)
                            Next
                            CommentsTemplateController.ProcessCommonTemplate(strHtml, TemplateHelper.Template_CommentFooter, lstComments, Settings)

                        Case "participants"

                            Dim lstParticipants As List(Of ParticipantInfo) = ParticipantController.ListByProject(objProject.ProjectId)
                            ParticipantsTemplateController.ProcessCommonTemplate(strHtml, TemplateHelper.Template_ParticipantsHeader, lstParticipants, Settings)
                            For Each objParticipant As ParticipantInfo In lstParticipants
                                ParticipantsTemplateController.ProcessItemTemplate(strHtml, TemplateHelper.Template_ParticipantsItem, objParticipant, Settings)
                            Next
                            ParticipantsTemplateController.ProcessCommonTemplate(strHtml, TemplateHelper.Template_ParticipantsFooter, lstParticipants, Settings)

                        Case "approveprojecturl"

                            If objProject.IsVisible Then
                                strHtml += "javascript:UnApproveProject(" & objProject.ModuleId & "," & objProject.ProjectId & ");"
                            Else
                                strHtml += "javascript:ApproveProject(" & objProject.ModuleId & "," & objProject.ProjectId & ");"
                            End If


                        Case "editprojecturl"

                            strHtml += NavigateURL(Portalsettings.ActiveTab.TabID, "", "Action=EditProject", "ProjectId=" & objProject.ProjectId.ToString)

                        Case "lockprojecturl"

                            If objProject.IsLocked Then
                                strHtml += "javascript:UnLockProject(" & objProject.ModuleId & "," & objProject.ProjectId & ");"
                            Else
                                strHtml += "javascript:LockProject(" & objProject.ModuleId & "," & objProject.ProjectId & ");"
                            End If

                        Case "deleteprojecturl"

                            strHtml += "javascript:DeleteProject(" & objProject.ModuleId & "," & objProject.ProjectId & ");"

                        Case Else

                            If (templateArray(iPtr + 1).ToUpper().StartsWith("RESX:")) Then

                                Dim key As String = templateArray(iPtr + 1).Substring(5, templateArray(iPtr + 1).Length - 5)

                                Select Case key
                                    Case "cmdLockProject"
                                        If objProject.IsLocked Then
                                            strHtml += Utilities.GetSharedResource("cmdUnLockProject")
                                        Else
                                            strHtml += Utilities.GetSharedResource(key)
                                        End If

                                    Case "cmdApproveProject"
                                        If objProject.IsVisible Then
                                            strHtml += Utilities.GetSharedResource("cmdUnApproveProject")
                                        Else
                                            strHtml += Utilities.GetSharedResource("cmdApproveProject")
                                        End If

                                    Case "cmdDeleteProject"
                                        If objProject.IsDeleted Then
                                            strHtml += Utilities.GetSharedResource("cmdUnDeleteProject")
                                        Else
                                            strHtml += Utilities.GetSharedResource("cmdDeleteProject")
                                        End If

                                    Case Else

                                        strHtml += Utilities.GetSharedResource(key)

                                End Select

                            End If

                    End Select
                End If
            Next

        End Sub

    End Class

End Namespace

