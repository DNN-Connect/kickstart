﻿Namespace Connect.Modules.Kickstart
    Public Class KickstartSettings

        Public ModuleTheme As String = Null.NullString
        Public ThemePath As String = Null.NullString
        Public ViewMode As String = Null.NullString
        Public ProjectListTabId As Integer = Null.NullInteger
        Public ProjectDetailsTabId As Integer = Null.NullInteger

        Public Sub New(ModuleSettings As Hashtable)

            If ModuleSettings.Contains("Kickstart_ModuleTheme") Then
                ModuleTheme = ModuleSettings("Kickstart_ModuleTheme").ToString
                ThemePath = GetThemePath()
            End If

            If ModuleSettings.Contains("Kickstart_ViewMode") Then
                ViewMode = ModuleSettings("Kickstart_ViewMode").ToString
            End If

            If ModuleSettings.Contains("Kickstart_RedirectTabId") Then
                If IsNumeric(ModuleSettings("Kickstart_RedirectTabId")) Then
                    ProjectDetailsTabId = Convert.ToInt32(ModuleSettings("Kickstart_RedirectTabId"))
                    ProjectListTabId = Convert.ToInt32(ModuleSettings("Kickstart_RedirectTabId"))
                End If
            End If

        End Sub

        Private Function GetThemePath() As String

            Dim absTemplateFolderPath As String = HttpRuntime.AppDomainAppPath & "Desktopmodules\Connect\Kickstart\Templates\"
            absTemplateFolderPath += ModuleTheme & "\"

            Return absTemplateFolderPath.Replace("\\", "\")

        End Function

    End Class

End Namespace

