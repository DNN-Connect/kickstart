﻿
Imports DotNetNuke
Imports DotNetNuke.Services.Exceptions


Namespace Connect.Modules.Kickstart
    Public Class Settings
        Inherits SettingsBase

#Region "Base Method Implementations"

        Public Overrides Sub LoadSettings()
            Try
                If (Page.IsPostBack = False) Then

                    BindThemes()
                    BindTabs()

                    Try 'since the theme folder might have been deleted by an unknown bastard we need to be careful here
                        If (Settings.Contains("Kickstart_ModuleTheme")) Then drpModuleTheme.SelectedValue = Settings("Kickstart_ModuleTheme").ToString()
                    Catch
                    End Try

                    If (Settings.Contains("Kickstart_ViewMode")) Then drpViewMode.SelectedValue = Settings("Kickstart_ViewMode").ToString()
                    If (Settings.Contains("Kickstart_RedirectTabId")) Then drpRedirectTab.SelectedValue = Settings("Kickstart_RedirectTabId").ToString()

                    BindRedirectControls()

                End If
            Catch exc As Exception           'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

        Public Overrides Sub UpdateSettings()
            Try

                Dim objModules As New DotNetNuke.Entities.Modules.ModuleController

                objModules.UpdateModuleSetting(ModuleId, "Kickstart_ModuleTheme", drpModuleTheme.SelectedValue)
                objModules.UpdateModuleSetting(ModuleId, "Kickstart_ViewMode", drpViewMode.SelectedValue)
                objModules.UpdateModuleSetting(ModuleId, "Kickstart_RedirectTabId", drpRedirectTab.SelectedValue)

            Catch exc As Exception           'Module failed to load
                ProcessModuleLoadException(Me, exc)
            End Try
        End Sub

#End Region

#Region "Private Methods"

        Private Sub BindThemes()

            drpModuleTheme.Items.Clear()
            Dim basepath As String = Server.MapPath(Me.TemplateSourceDirectory & "/templates/")

            For Each folder As String In System.IO.Directory.GetDirectories(basepath)
                Dim foldername As String = folder.Substring(folder.LastIndexOf("\") + 1)

                drpModuleTheme.Items.Add(New ListItem(foldername, foldername))

            Next

        End Sub

        Private Sub BindTabs()

            Dim tabs As System.Collections.Generic.List(Of DotNetNuke.Entities.Tabs.TabInfo) = TabController.GetPortalTabs(PortalId, Null.NullInteger, True, True, False, False)

            drpRedirectTab.DataSource = tabs
            drpRedirectTab.DataBind()

        End Sub

        Private Sub BindRedirectControls()

            rowRedirectTab.Visible = (drpViewMode.SelectedIndex = 0 Or drpViewMode.SelectedIndex = 1)

            If drpViewMode.SelectedIndex = 0 Then
                lblRedirectTab.Text = Localization.GetString("lblDetailsTabId", LocalResourceFile)
            End If

            If drpViewMode.SelectedIndex = 1 Then
                lblRedirectTab.Text = Localization.GetString("lblListTabId", LocalResourceFile)
            End If

        End Sub

#End Region

#Region "Event Handlers"

        Private Sub drpViewMode_SelectedIndexChanged(sender As Object, e As EventArgs) Handles drpViewMode.SelectedIndexChanged

            BindRedirectControls()

        End Sub

#End Region

    End Class
End Namespace
