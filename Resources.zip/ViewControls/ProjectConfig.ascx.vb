﻿Imports Connect.Modules.Kickstart.Entities

Namespace Connect.Modules.Kickstart
    Public Class ProjectConfig
        Inherits KickstartModuleBase


#Region "Event Handlers"

        Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

            DotNetNuke.Framework.AJAX.RegisterScriptManager()

            ReadQuerystring()

            If Project Is Nothing Then
                HideModule()
            End If

        End Sub

        Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

            If Not IsProjectLead() Then
                HideModule()
            End If

            BindLocalization()

            If Not Project Is Nothing Then
                If Project.CreatedBy <> UserInfo.UserID Then
                    'todo: hide me
                End If
            End If


            If Not Page.IsPostBack Then
                If Not ProjectId = Null.NullInteger Then

                    BindConfig()
                    BindIncentives()

                End If
            End If

        End Sub

        Protected Sub cmdUpdateConfig_Click(sender As Object, e As System.EventArgs) Handles cmdUpdateConfig.Click
            UpdateConfig()
            RefreshPage()
        End Sub

        Public Sub cmdEditIncentive_Click(sender As Object, e As System.EventArgs)
            Dim IncentiveId As Integer = Convert.ToInt32(CType(sender, ImageButton).CommandArgument)
            BindIncentive(IncentiveId)
        End Sub

        Public Sub cmdDeleteIncentive_Click(sender As Object, e As System.EventArgs)
            Dim IncentiveId As Integer = Convert.ToInt32(CType(sender, ImageButton).CommandArgument)
            IncentiveController.Delete(IncentiveId)
            RefreshPage()
        End Sub

        Protected Sub cmdAddIncentive_Click(sender As Object, e As System.EventArgs) Handles cmdAddIncentive.Click
            UpdateIncentive()
            RefreshPage()
        End Sub

#End Region

#Region "Templating"


#End Region

#Region "Private Methods"

        Private Sub BindIncentive(IncentiveId As Integer)

            Dim objIncentive As IncentiveInfo = IncentiveController.Get(IncentiveId)
            If Not objIncentive Is Nothing Then
                txtIncentive.Text = objIncentive.Incentive
                ctlFundingAmount.Value = objIncentive.Amount
            End If

        End Sub

        Private Sub BindLocalization()

            lblFundingAmount.Text = Localization.GetString("lblFundingAmount", LocalResourceFile)
            lblFundingQuestion.Text = Localization.GetString("lblFundingQuestion", LocalResourceFile)
            lblHeading.Text = Localization.GetString("lblHeading", LocalResourceFile)
            lblIncentive.Text = Localization.GetString("lblIncentive", LocalResourceFile)
            lblResourcesQuestion.Text = Localization.GetString("lblResourcesQuestion", LocalResourceFile)
            lblIncentiveIntro.Text = Localization.GetString("lblIncentiveIntro", LocalResourceFile)
            lblFundingIntro.Text = Localization.GetString("lblFundingIntro", LocalResourceFile)
            lblIncentives.Text = Localization.GetString("lblIncentives", LocalResourceFile)

        End Sub

        Private Sub BindConfig()

            Dim config As ProjectConfigInfo = ConfigController.GetConfig(ProjectId)

            If config Is Nothing Then
                config = New ProjectConfigInfo
                config.DesignersNeeded = 0
                config.DevelopersNeeded = 0
                config.FundingNeeded = CDec(0.0)
                config.ManagersNeeded = 1
                config.TestersNeeded = 0
                config.TranslatorsNeeded = 0
                ConfigController.UpdateConfig(ProjectId, 0, 0, 0, 1, 0, 0, drpFundingCurrency.SelectedValue)
            End If

            ctlDevelopersNeeded.Value = Convert.ToDecimal(config.DevelopersNeeded)
            ctlDesignersNeeded.Value = Convert.ToDecimal(config.DesignersNeeded)
            ctlFundingNeeded.Value = Convert.ToDecimal(config.FundingNeeded)
            ctlManagersNeeded.Value = Convert.ToDecimal(config.ManagersNeeded)
            ctlTestersNeeded.Value = Convert.ToDecimal(config.TestersNeeded)
            ctlTranslatorsNeeded.Value = Convert.ToDecimal(config.TranslatorsNeeded)

            drpFundingCurrency.SelectedValue = config.FundingCurrency

        End Sub

        Private Sub UpdateConfig()

            Dim intDevelopers As Integer = Convert.ToInt32(ctlDevelopersNeeded.Value)
            Dim intDesigners As Integer = Convert.ToInt32(ctlDesignersNeeded.Value)
            Dim intTesters As Integer = Convert.ToInt32(ctlTestersNeeded.Value)
            Dim intTranslators As Integer = Convert.ToInt32(ctlTranslatorsNeeded.Value)
            Dim intManagers As Integer = Convert.ToInt32(ctlManagersNeeded.Value)
            Dim decFunding As Integer = Convert.ToDecimal(ctlFundingNeeded.Value)

            ConfigController.UpdateConfig(ProjectId, intDevelopers, intDesigners, intTesters, intManagers, intTranslators, decFunding, drpFundingCurrency.SelectedValue)

        End Sub

        Private Sub UpdateIncentive()

            Dim Amount As Decimal = ctlFundingAmount.DbValue
            Dim Incentive As String = txtIncentive.Text

            Dim objIncentive As IncentiveInfo = IncentiveController.GetByAmount(ProjectId, Amount)

            If Not objIncentive Is Nothing Then

                If String.IsNullOrEmpty(Incentive) Then
                    IncentiveController.Delete(objIncentive.IncentiveId)
                ElseIf Amount = CDec(0.0) Then
                    IncentiveController.Delete(objIncentive.IncentiveId)
                Else
                    objIncentive.Amount = Amount
                    objIncentive.Incentive = Incentive
                    IncentiveController.Update(objIncentive)
                End If
            Else

                If Not String.IsNullOrEmpty(Incentive) AndAlso Not (Amount = CDec(0.0)) Then

                    objIncentive = New IncentiveInfo
                    objIncentive.ProjectId = ProjectId
                    objIncentive.Amount = Amount
                    objIncentive.Incentive = Incentive
                    IncentiveController.Add(objIncentive)

                End If

            End If

        End Sub

        Private Sub BindIncentives()

            Dim incentives As New List(Of IncentiveInfo)
            incentives = IncentiveController.ListByProject(ProjectId)

            rptIncentives.DataSource = incentives
            rptIncentives.DataBind()

        End Sub

#End Region

#Region "Public Methods"

        Public Function GetCurrency() As String
            Return FormatCurrency(ConfigController.GetConfig(ProjectId).FundingCurrency)
        End Function

#End Region

    End Class
End Namespace
