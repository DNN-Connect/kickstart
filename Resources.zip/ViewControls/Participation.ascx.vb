﻿Imports Connect.Modules.Kickstart.Entities
Imports Connect.Modules.Kickstart.Entities.ParticipantInfo

Namespace Connect.Modules.Kickstart
    Public Class Participation
        Inherits KickstartModuleBase


#Region "Event Handlers"

        Protected Sub Page_Init(sender As Object, e As System.EventArgs) Handles Me.Init

            DotNetNuke.Framework.AJAX.RegisterScriptManager()

            ReadQuerystring()
            If Project Is Nothing Then
                HideModule()
            End If

        End Sub

        Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

            BindLocalization()

            If Not Page.IsPostBack Then
                If Not Project Is Nothing Then

                    BindOwnership()
                    BindConfig()
                    BindPartcipation()
                    BindProjectInfo()
                    BindFunding()

                End If
            End If

        End Sub

        Protected Sub cmdAddFunding_Click(sender As Object, e As System.EventArgs) Handles cmdAddFunding.Click

            If Request.IsAuthenticated = False Then
                Response.Redirect(NavigateURL(PortalSettings.RegisterTabId, "", "ReturnUrl=" & Server.UrlEncode(ProjectUrl(ProjectId))))
            End If

            UpdateFunding()
            RefreshPage()

        End Sub

        Protected Sub cmdDeleteFunding_Click(sender As Object, e As System.EventArgs) Handles cmdDeleteFunding.Click

            If Request.IsAuthenticated = False Then
                Response.Redirect(NavigateURL(PortalSettings.RegisterTabId, "", "ReturnUrl=" & Server.UrlEncode(ProjectUrl(ProjectId))))
            End If

            RemoveFunding()
            RefreshPage()
        End Sub

        Protected Sub cmdTakeOwnership_Click(sender As Object, e As System.EventArgs) Handles cmdTakeOwnership.Click

            If Request.IsAuthenticated = False Then
                Response.Redirect(NavigateURL(PortalSettings.RegisterTabId, "", "ReturnUrl=" & Server.UrlEncode(ProjectUrl(ProjectId))))
            End If

            TakeOwnership()
            RefreshPage()

        End Sub

        Protected Sub btnParticipate_Click(sender As Object, e As System.EventArgs) Handles btnParticipate.Click

            If Request.IsAuthenticated = False Then
                Response.Redirect(NavigateURL(PortalSettings.RegisterTabId, "", "ReturnUrl=" & Server.UrlEncode(ProjectUrl(ProjectId))))
            End If

            Participate()
            RefreshPage()

        End Sub

        Protected Sub drpFundingAmount_SelectedIndexChanged(sender As Object, e As System.EventArgs) Handles drpFundingAmount.SelectedIndexChanged
            BindIncentiveDescription()
        End Sub

#End Region

#Region "Templating"


#End Region

#Region "Private Methods"

        Private Sub TakeOwnership()

            Dim lst As New List(Of Integer)
            lst.Add(ParticipantRole.Manager)
            ParticipantController.UpdateParticipation(lst, ProjectId, UserId)

            ConfigController.UpdateOwnership(ProjectId, UserId)

        End Sub

        Private Sub Participate()

            Dim myList As New List(Of Integer)

            If chkDesigners.Visible AndAlso chkDesigners.Checked Then
                myList.Add(ParticipantRole.Designer)
            End If
            If chkDevelopers.Visible AndAlso chkDevelopers.Checked Then
                myList.Add(ParticipantRole.Developer)
            End If
            If chkManagers.Visible AndAlso chkManagers.Checked Then
                myList.Add(ParticipantRole.Manager)
            Else
                If IsProjectLead() Then
                    myList.Add(ParticipantRole.Manager)
                End If
            End If
            If chkTesters.Visible AndAlso chkTesters.Checked Then
                myList.Add(ParticipantRole.Tester)
            End If
            If chkTranslators.Visible AndAlso chkTranslators.Checked Then
                myList.Add(ParticipantRole.Translator)
            End If

            ParticipantController.UpdateParticipation(myList, ProjectId, UserId)

        End Sub

        Private Sub BindIncentiveDescription()

            Dim incentives As New List(Of IncentiveInfo)
            incentives = IncentiveController.ListByProject(ProjectId)

            For Each i As IncentiveInfo In incentives
                If i.IncentiveId.ToString = drpFundingAmount.SelectedValue Then
                    lblFundingIncentive.Text = i.Incentive
                End If
            Next

        End Sub

        Private Sub BindPartcipation()

            If Not Config.InitializedOnly Then

                Dim lst As New List(Of ParticipantInfo)
                lst = ParticipantController.GetUserParticipation(UserId, ProjectId)

                If lst.Count > 0 Then
                    lblParticipateIntro.Text = Localization.GetString("AlreadyParticipating", LocalResourceFile)
                    btnParticipate.Text = Localization.GetString("btnUpdateParticipation", LocalResourceFile)
                Else
                    lblParticipateIntro.Text = Localization.GetString("Participate", LocalResourceFile)
                    btnParticipate.Text = Localization.GetString("btnParticipate", LocalResourceFile)
                End If

                For Each p As ParticipantInfo In lst
                    If p.ProjectRole = ParticipantRole.Designer Then
                        chkDesigners.Checked = True
                    End If
                    If p.ProjectRole = ParticipantRole.Developer Then
                        chkDevelopers.Checked = True
                    End If
                    If p.ProjectRole = ParticipantRole.Manager Then
                        chkManagers.Checked = True
                        chkManagers.Enabled = False
                    End If
                    If p.ProjectRole = ParticipantRole.Tester Then
                        chkTesters.Checked = True
                    End If
                    If p.ProjectRole = ParticipantRole.Translator Then
                        chkTranslators.Checked = True
                    End If
                Next

            End If

        End Sub

        Private Sub BindProjectInfo()

            If Not Project Is Nothing Then

                lblProjectInfo.Text = "<strong>" & Project.Subject & ":</strong> " & HtmlUtils.Shorten(Project.Content, 400, "...")
                lnkIdea.NavigateUrl = ProjectListUrl()

            End If

        End Sub

        Private Sub BindOwnership()


            If HasProjectLead() Then

                pnlTakeOwnership.Visible = False

            Else

                lblOwnershipIntro.Text = Localization.GetString("NoOwnerYet", LocalResourceFile)
                pnlParticipation.Visible = False

            End If

        End Sub

        Private Sub BindLocalization()

            lblProjectInfoHeading.Text = Localization.GetString("lblProjectInfoHeading", LocalResourceFile)
            lnkIdea.Text = Localization.GetString("lnkIdea", LocalResourceFile)
            lblOwnerHeading.Text = Localization.GetString("lblOwnerHeading", LocalResourceFile)
            lblParticipateHeading.Text = Localization.GetString("lblParticipateHeading", LocalResourceFile)
            lblFundingHeader.Text = Localization.GetString("lblFundingHeader", LocalResourceFile)
            lblFundingIntro.Text = Localization.GetString("lblFundingIntro", LocalResourceFile)
            lblIncentiveHeading.Text = Localization.GetString("lblIncentiveHeading", LocalResourceFile)
            lblCustomFunding.Text = Localization.GetString("lblCustomFunding", LocalResourceFile)
            chkAnonymous.Text = Localization.GetString("chkAnonymous", LocalResourceFile)
            cmdTakeOwnership.Text = Localization.GetString("cmdTakeOwnership", LocalResourceFile)
            cmdAddFunding.Text = Localization.GetString("cmdAddFunding", LocalResourceFile)
            cmdDeleteFunding.Text = Localization.GetString("cmdDeleteFunding", LocalResourceFile)

        End Sub

        Private Sub BindFundingOptions()

            Dim incentives As New List(Of IncentiveInfo)
            incentives = IncentiveController.ListByProject(ProjectId)

            drpFundingAmount.Items.Clear()

            For Each i As IncentiveInfo In incentives
                Dim item As New ListItem
                item.Text = FormatCurrency(ConfigController.GetConfig(ProjectId).FundingCurrency) & " " & Utilities.FormatAmount(i.Amount)
                item.Value = i.IncentiveId.ToString
                drpFundingAmount.Items.Add(item)
            Next

            If incentives.Count > 0 Then
                lblFundingIncentive.Text = incentives(0).Incentive
            End If


        End Sub

        Private Sub BindConfig()

            If Not Config Is Nothing Then

                If IsProjectLead() And Config.InitializedOnly Then
                    lblParticipateIntro.Text = Localization.GetString("InitializedOnly", LocalResourceFile)
                    btnParticipate.Visible = False
                End If

                Dim participants As List(Of ParticipantInfo) = ParticipantController.ListByProject(ProjectId)

                For Each p As ParticipantInfo In participants
                    If p.ProjectRole = ParticipantRole.Designer Then
                        Config.DesignersNeeded -= 1
                    End If
                    If p.ProjectRole = ParticipantRole.Developer Then
                        Config.DevelopersNeeded -= 1
                    End If
                    If p.ProjectRole = ParticipantRole.Manager Then
                        Config.ManagersNeeded -= 1
                    End If
                    If p.ProjectRole = ParticipantRole.Tester Then
                        Config.TestersNeeded -= 1
                    End If
                    If p.ProjectRole = ParticipantRole.Translator Then
                        Config.TranslatorsNeeded -= 1
                    End If
                Next

                pnlFunding.Visible = Config.NeedsFunding
                If Config.NeedsFunding Then
                    BindFundingOptions()
                End If

                chkDesigners.Visible = Config.NeedsDesigners
                chkDesigners.Text += String.Format(Localization.GetString("OpenPositions", LocalResourceFile), Localization.GetString("groupDesigners", LocalResourceFile), Config.DesignersNeeded.ToString)

                chkDevelopers.Visible = Config.NeedsDevelopers
                chkDevelopers.Text += String.Format(Localization.GetString("OpenPositions", LocalResourceFile), Localization.GetString("groupDevelopers", LocalResourceFile), Config.DevelopersNeeded.ToString)

                chkManagers.Visible = Config.NeedsManagers
                chkManagers.Text += String.Format(Localization.GetString("OpenPositions", LocalResourceFile), Localization.GetString("groupManagers", LocalResourceFile), Config.ManagersNeeded.ToString)

                chkTesters.Visible = Config.NeedsTesters
                chkTesters.Text += String.Format(Localization.GetString("OpenPositions", LocalResourceFile), Localization.GetString("groupTesters", LocalResourceFile), Config.TestersNeeded.ToString)

                chkTranslators.Visible = Config.NeedsTranslators
                chkTranslators.Text += String.Format(Localization.GetString("OpenPositions", LocalResourceFile), Localization.GetString("groupTranslators", LocalResourceFile), Config.TranslatorsNeeded.ToString)


            End If
        End Sub

        Private Sub UpdateFunding()

            Dim objFunding As FundingInfo = Nothing

            If IsFunding() Then
                objFunding = MyFunding()
            Else
                objFunding = New FundingInfo
            End If

            objFunding.FundingReceived = False
            objFunding.Anonymous = chkAnonymous.Checked
            objFunding.ProjectId = ProjectId
            objFunding.UserId = UserId
            If ctlCustomFunding.DbValue > CDec(0.0) Then
                objFunding.Funding = ctlCustomFunding.DbValue
            Else
                objFunding.Funding = IncentiveController.Get(Convert.ToInt32(drpFundingAmount.SelectedValue)).Amount
            End If

            If IsFunding() Then
                FundingController.Update(objFunding)
            Else
                FundingController.Add(objFunding)
            End If

        End Sub

        Private Sub BindFunding()

            If IsFunding() Then
                cmdDeleteFunding.Visible = True
                cmdAddFunding.Text = Localization.GetString("cmdUpdateFunding", LocalResourceFile)
                lblFundingIntro.Text = String.Format(Localization.GetString("lblMyFunding", LocalResourceFile), MyFundingAsString)
            Else
                cmdDeleteFunding.Visible = False
            End If

        End Sub

        Private Sub RemoveFunding()
            If Not MyFunding() Is Nothing Then
                FundingController.Delete(MyFunding.FundingId)
            End If
        End Sub

#End Region

    End Class
End Namespace
