﻿Namespace Connect.Modules.Kickstart
    Public Class ProjectsList
        Inherits KickstartModuleBase


#Region "Event Handlers"

        Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

            ReadQuerystring()

        End Sub

        Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        End Sub

#End Region

#Region "Templating"


#End Region

#Region "Private Methods"


#End Region

    End Class
End Namespace
