﻿Imports DotNetNuke.Entities.Users
Imports Connect.Modules.Kickstart.Entities
Imports Connect.Modules.Kickstart.Entities.ParticipantInfo

Namespace Connect.Modules.Kickstart
    Public Class ProjectMembers
        Inherits KickstartModuleBase


#Region "Event Handlers"

        Protected Sub Page_Init(sender As Object, e As System.EventArgs) Handles Me.Init

            DotNetNuke.Framework.AJAX.RegisterScriptManager()

            ReadQuerystring()
            If Project Is Nothing Then
                HideModule()
            End If

        End Sub

        Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

            If Not Page.IsPostBack Then
                If Not Project Is Nothing Then

                    If Not Config Is Nothing Then

                        Dim objLead As UserInfo = UserController.GetUserById(PortalId, Config.ProjectOwner)
                        If objLead Is Nothing Then
                            pnlLead.Visible = False
                        Else
                            lblOwnerHead.Text = Localization.GetString("lblOwnerHead", LocalResourceFile)
                            imgLead.ImageUrl = "~/ProfilePic.ashx?UserId=" & objLead.UserID.ToString
                            lblLeadName.Text = objLead.DisplayName
                            lnkLeadProfile.NavigateUrl = NavigateURL(PortalSettings.UserTabId, "", "UserId=" & objLead.UserID.ToString)
                            lnkLeadProfile.Text = Localization.GetString("FullProfileUrl", LocalResourceFile)

                            BindOtherMembers()

                        End If

                    End If

                End If
            End If

        End Sub

#End Region

#Region "Templating"


#End Region

#Region "Private Methods"

        Private Sub BindOtherMembers()

            Dim lst As New List(Of ParticipantInfo)
            lst = GetParticipantList(ParticipantRole.Manager, True)

            If lst.Count > 0 Then
                lblManagers.Text = Localization.GetString("lblManagers", LocalResourceFile)
                rptManagers.DataSource = lst
                rptManagers.DataBind()
            Else
                pnlManagers.Visible = False
            End If

            lst = GetParticipantList(ParticipantRole.Designer, True)

            If lst.Count > 0 Then
                lblDesigners.Text = Localization.GetString("lblDesigners", LocalResourceFile)
                rptDesigners.DataSource = lst
                rptDesigners.DataBind()
            Else
                pnlDesigners.Visible = False
            End If

            lst = GetParticipantList(ParticipantRole.Developer, True)

            If lst.Count > 0 Then
                lblDevelopers.Text = Localization.GetString("lblDevelopers", LocalResourceFile)
                rptDevelopers.DataSource = lst
                rptDevelopers.DataBind()
            Else
                pnlDevelopers.Visible = False
            End If

            lst = GetParticipantList(ParticipantRole.Tester, True)

            If lst.Count > 0 Then
                lblTesters.Text = Localization.GetString("lblTesters", LocalResourceFile)
                rptTesters.DataSource = lst
                rptTesters.DataBind()
            Else
                pnlTesters.Visible = False
            End If

            lst = GetParticipantList(ParticipantRole.Translator, True)

            If lst.Count > 0 Then
                lblTranslators.Text = Localization.GetString("lblTranslators", LocalResourceFile)
                rptTranslators.DataSource = lst
                rptTranslators.DataBind()
            Else
                pnlTranslators.Visible = False
            End If

        End Sub

#End Region

    End Class
End Namespace
