﻿Imports Connect.Modules.Kickstart.Entities

Namespace Connect.Modules.Kickstart
    Public Class Funding
        Inherits KickstartModuleBase


#Region "Event Handlers"

        Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init

            ReadQuerystring()

            If Project Is Nothing Then
                HideModule()
            End If

        End Sub

        Protected Sub Page_Load(sender As Object, e As System.EventArgs) Handles Me.Load

            BindLocalization()

            If Not Page.IsPostBack Then
                If Not Project Is Nothing Then

                    BindFunds()

                End If
            End If

        End Sub

#End Region

#Region "Templating"


#End Region

#Region "Private Methods"

        Private Sub BindLocalization()

            lblFundingHead.Text = Localization.GetString("lblFundingHead", LocalResourceFile)

        End Sub

        Private Sub BindFunds()

            If Not Config Is Nothing Then

                Dim CurrentFunding As Decimal = FundingController.GetFunds(ProjectId)
                Dim NeededFunding As Decimal = Config.FundingNeeded
                Dim spanHtmlPercent As String = "0%"

                If NeededFunding > CDec(0.0) Then

                    Select Case CurrentFunding / NeededFunding
                        Case Is >= CDec(1.0)
                            spanHtmlPercent = "100%"
                        Case Is >= CDec(0.9)
                            spanHtmlPercent = "90%"
                        Case Is >= CDec(0.8)
                            spanHtmlPercent = "80%"
                        Case Is >= CDec(0.7)
                            spanHtmlPercent = "70%"
                        Case Is >= CDec(0.6)
                            spanHtmlPercent = "60%"
                        Case Is >= CDec(0.5)
                            spanHtmlPercent = "50%"
                        Case Is >= CDec(0.4)
                            spanHtmlPercent = "40%"
                        Case Is >= CDec(0.3)
                            spanHtmlPercent = "30%"
                        Case Is >= CDec(0.2)
                            spanHtmlPercent = "20%"
                        Case Is >= CDec(0.1)
                            spanHtmlPercent = "10%"
                    End Select

                    lblMeterSpan.Text = "<span style=""width: " & spanHtmlPercent & """></span>"

                    lblFundingNeeded.Text = String.Format(Localization.GetString("lblFundingNeeded", LocalResourceFile), Utilities.FormatCurrency(Config.FundingCurrency), Utilities.FormatAmount(NeededFunding))
                    lblFundingReached.Text = String.Format(Localization.GetString("lblFundingReached", LocalResourceFile), FormatCurrency(Config.FundingCurrency), Utilities.FormatAmount(CurrentFunding))

                Else

                    HideModule()

                End If

            Else

                HideModule()

            End If


        End Sub

#End Region

    End Class
End Namespace
